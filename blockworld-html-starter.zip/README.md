# BlockWorld — HTML Voxel Sandbox

An original Minecraft-like voxel sandbox prototype built with HTML, CSS, JavaScript, and Three.js.

## Features
- 3D block terrain, hills, trees, sky, and fog
- Procedural pixel-art-style block textures generated locally in Canvas
- Place and break blocks
- Six-slot hotbar
- Keyboard/mouse controls and experimental touch controls
- Reset world button
- Extra ore materials (coal, iron, gold, diamond)

## Run
Open `index.html` in a browser with internet access. The game imports Three.js from jsDelivr, so an internet connection is needed to load the 3D library.

## GitHub Pages
1. Create a public repository named `minecraft-html`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for the deployment URL to appear.

## Note
This is an early prototype. Collision, mobile look controls, and world generation can be refined further.
